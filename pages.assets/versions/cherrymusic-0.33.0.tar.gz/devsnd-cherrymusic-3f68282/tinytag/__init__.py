from .tinytag import TinyTag, StringWalker, ID3, Ogg, Wave, Flac


__version__ = '0.7.1'
