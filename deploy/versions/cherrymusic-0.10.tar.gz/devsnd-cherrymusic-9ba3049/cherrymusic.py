import cherrymusic

if __name__ == "__main__":
    cherrymusic.CherryMusic()
    
