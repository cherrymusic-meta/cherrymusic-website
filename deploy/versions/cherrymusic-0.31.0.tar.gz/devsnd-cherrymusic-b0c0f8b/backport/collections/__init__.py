#!/usr/bin/python3
# -*- coding: utf-8 -*-
from collections import *

if not 'OrderedDict' in dir():
    from _backported import OrderedDict
