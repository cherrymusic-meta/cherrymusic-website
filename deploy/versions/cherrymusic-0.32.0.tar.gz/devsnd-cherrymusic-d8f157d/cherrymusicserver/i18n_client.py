def get():
    return {
        'track has no path set!': _('track has no path set!'),
        'track has no label set!': _('track has no label set!'),
    }