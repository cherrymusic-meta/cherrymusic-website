from collections import *

if not 'OrderedDict' in dir():
    from _backported import OrderedDict
